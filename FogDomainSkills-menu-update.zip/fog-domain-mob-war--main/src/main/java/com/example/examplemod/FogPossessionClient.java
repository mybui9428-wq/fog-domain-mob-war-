
package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;

@EventBusSubscriber(
        modid = ExampleMod.MODID,
        value = Dist.CLIENT
)
public final class FogPossessionClient {

    private FogPossessionClient() {
    }

    // true khi người chơi đang điều khiển linh hồn.
    public static boolean soulMode = false;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {

        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.player == null || minecraft.level == null) {
            return;
        }

        Entity camera = minecraft.getCameraEntity();

        if (camera == null) {
            return;
        }

        // Không gửi điều khiển khi đang chơi bình thường.
        // Vẫn gửi khi điều khiển sinh vật hoặc linh hồn.
        if (camera == minecraft.player && !soulMode) {
            return;
        }

        float forward = 0.0F;
        float strafe = 0.0F;

        if (minecraft.options.keyUp.isDown()) {
            forward += 1.0F;
        }

        if (minecraft.options.keyDown.isDown()) {
            forward -= 1.0F;
        }

        if (minecraft.options.keyLeft.isDown()) {
            strafe -= 1.0F;
        }

        if (minecraft.options.keyRight.isDown()) {
            strafe += 1.0F;
        }

        float yaw = camera.getYRot();
        float pitch = camera.getXRot();

        boolean jump = minecraft.options.keyJump.isDown();
        boolean attack = minecraft.options.keyAttack.isDown();

        ClientPacketDistributor.sendToServer(
                new FogPossessionControlPayload(
                        forward,
                        strafe,
                        yaw,
                        pitch,
                        jump,
                        attack
                )
        );
    }
}
