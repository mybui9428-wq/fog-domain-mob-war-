
package com.example.examplemod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.TextAlignment;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.client.network.event.RegisterClientPayloadHandlersEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;

@Mod(value = ExampleMod.MODID, dist = Dist.CLIENT)
@EventBusSubscriber(
        modid = ExampleMod.MODID,
        value = Dist.CLIENT
)
public class ExampleModClient {

    private static String hudData = "";

    // Lớp thanh máu mặc định của Minecraft.
    private static final Identifier VANILLA_HEALTH_LAYER =
            VanillaGuiLayers.PLAYER_HEALTH;

    public ExampleModClient(ModContainer container) {
        container.registerExtensionPoint(
                IConfigScreenFactory.class,
                ConfigurationScreen::new
        );
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        ExampleMod.LOGGER.info("FOG DOMAIN CLIENT READY");
    }

    @SubscribeEvent
    public static void registerClientPayloads(
            RegisterClientPayloadHandlersEvent event
    ) {

        // Nhận dữ liệu điều khiển Nhập Hồn.
        event.register(
                FogPossessionSyncPayload.TYPE,
                (payload, context) -> {

                    Minecraft minecraft = Minecraft.getInstance();

                    if (minecraft.player == null
                            || minecraft.level == null) {
                        return;
                    }

                    if (payload.action() == 1) {

                        Entity target = minecraft.level.getEntity(
                                payload.targetId()
                        );

                        if (target != null) {
                            FogPossessionClient.soulMode = false;
                            minecraft.setCameraEntity(target);
                        }
                    }

                    else if (payload.action() == 0) {

                        FogPossessionClient.soulMode = false;
                        minecraft.setCameraEntity(minecraft.player);
                    }

                    else if (payload.action() == 2) {

                        FogPossessionClient.soulMode = true;
                        minecraft.setCameraEntity(minecraft.player);
                    }

                    else if (payload.action() == 3) {

                        FogPossessionClient.soulMode = false;
                        minecraft.setCameraEntity(minecraft.player);
                    }
                }
        );

        // Nhận dữ liệu HUD từ máy chủ.
        event.register(
                FogHudPayload.TYPE,
                (payload, context) -> {
                    hudData = payload.data();
                }
        );

        // Nhận dữ liệu bảng thuộc tính và cấp độ kỹ năng.
        event.register(
                FogCharacterPayload.TYPE,
                (payload, context) -> {

                    String[] parts = payload.data().split("\\|", -1);

                    if (parts.length < 20
                            || !parts[0].equals("update")) {
                        return;
                    }

                    try {
                        // Thông tin nhân vật.
                        int level = Integer.parseInt(parts[1]);
                        int spiritPoints = Integer.parseInt(parts[2]);
                        int freePoints = Integer.parseInt(parts[3]);
                        int ruleFragments = Integer.parseInt(parts[4]);
                        int soulCrystals = Integer.parseInt(parts[5]);

                        // Năm thuộc tính.
                        int agility = Integer.parseInt(parts[6]);
                        int stamina = Integer.parseInt(parts[7]);
                        int strength = Integer.parseInt(parts[8]);
                        int spirit = Integer.parseInt(parts[9]);
                        int charisma = Integer.parseInt(parts[10]);

                        // Máu.
                        float health = Float.parseFloat(parts[11]);
                        float maxHealth = Float.parseFloat(parts[12]);

                        // Thông báo.
                        String message = parts[13];

                        // Cấp độ sáu kỹ năng.
                        int energySkillLevel =
                                Integer.parseInt(parts[14]);

                        int cageSkillLevel =
                                Integer.parseInt(parts[15]);

                        int tameSkillLevel =
                                Integer.parseInt(parts[16]);

                        int combineSkillLevel =
                                Integer.parseInt(parts[17]);

                        int stealSkillLevel =
                                Integer.parseInt(parts[18]);

                        int tripleSpiritSkillLevel =
                                Integer.parseInt(parts[19]);

                        Minecraft.getInstance().execute(() -> {
                            FogCharacterScreen.updateData(
                                    level,
                                    spiritPoints,
                                    freePoints,
                                    ruleFragments,
                                    soulCrystals,
                                    agility,
                                    stamina,
                                    strength,
                                    spirit,
                                    charisma,
                                    health,
                                    maxHealth,
                                    message,
                                    energySkillLevel,
                                    cageSkillLevel,
                                    tameSkillLevel,
                                    combineSkillLevel,
                                    stealSkillLevel,
                                    tripleSpiritSkillLevel
                            );
                        });

                    } catch (NumberFormatException exception) {
                        ExampleMod.LOGGER.error(
                                "Du lieu bang nhan vat khong hop le",
                                exception
                        );
                    }
                }
        );
    }

    /**
     * Ẩn trái tim mặc định của Minecraft.
     */
    @SubscribeEvent
    public static void hideVanillaHealth(
            RenderGuiLayerEvent.Pre event
    ) {
        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.player == null
                || minecraft.level == null) {
            return;
        }

        if (VANILLA_HEALTH_LAYER.equals(event.getName())) {
            event.setCanceled(true);
        }
    }

    /**
     * Hiển thị máu bằng số.
     */
    @SubscribeEvent
    public static void renderNumericHealth(
            RenderGuiEvent.Post event
    ) {
        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.player == null
                || minecraft.level == null) {
            return;
        }

        float health = minecraft.player.getHealth();
        float maxHealth = minecraft.player.getMaxHealth();

        String healthText = String.format(
                java.util.Locale.ROOT,
                "%.0f / %.0f HP",
                health,
                maxHealth
        );

        GuiGraphicsExtractor graphics =
                event.getGuiGraphics();

        int screenWidth =
                minecraft.getWindow().getGuiScaledWidth();

        int screenHeight =
                minecraft.getWindow().getGuiScaledHeight();

        var textRenderer = graphics.textRenderer(
                GuiGraphicsExtractor.HoveredTextEffects.NONE
        );

        textRenderer.accept(
                TextAlignment.CENTER,
                screenWidth / 2,
                screenHeight - 40,
                textRenderer.defaultParameters(),
                Component.literal(healthText)
        );
    }

    // Vẽ bảng trạng thái trên màn hình.
    @SubscribeEvent
    public static void renderHud(RenderGuiEvent.Post event) {

        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.player == null
                || minecraft.level == null) {
            return;
        }

        if (!minecraft.player.getName().getString()
                .equalsIgnoreCase("tubi2531")) {
            return;
        }

        if (hudData == null || hudData.isBlank()) {
            return;
        }

        GuiGraphicsExtractor graphics =
                event.getGuiGraphics();

        int x = 8;
        int y = 8;
        int width = 190;

        String[] lines = hudData.split("\\n");

        int visibleLines = Math.min(lines.length, 12);
        int height = 14 + visibleLines * 12;

        graphics.fill(
                x,
                y,
                x + width,
                y + height,
                0xCC101820
        );

        graphics.fill(
                x,
                y,
                x + width,
                y + 2,
                0xFF55DDEE
        );

        var textRenderer = graphics.textRenderer(
                GuiGraphicsExtractor.HoveredTextEffects.NONE
        );

        textRenderer.accept(
                TextAlignment.LEFT,
                x + 7,
                y + 6,
                textRenderer.defaultParameters(),
                Component.literal("LINH VUC SUONG MU")
        );

        for (int i = 0; i < visibleLines; i++) {

            textRenderer.accept(
                    TextAlignment.LEFT,
                    x + 7,
                    y + 20 + i * 12,
                    textRenderer.defaultParameters(),
                    Component.literal(lines[i])
            );
        }
    }
}
